import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.ml.{Pipeline, PipelineModel, Transformer}
import org.apache.spark.ml.feature.{OneHotEncoder, StringIndexer, VectorAssembler}
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.sql.types.{DoubleType, IntegerType, StructField, StructType}
import org.apache.spark.sql.functions._
import org.apache.spark.ml.util.Identifiable
import org.apache.spark.rdd

import java.io.PrintWriter

object Titanic extends App {
  implicit val spark = SparkSession
    .builder()
    .master("local[*]")
    .appName("Titanic")
    .getOrCreate()
  spark.sparkContext.setLogLevel("ERROR")
  val train = spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .csv("src/main/resources/train.csv")

  val test = spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .csv("src/main/resources/test.csv")

  println("train")
  train.printSchema()
  train.show()
  println("test")
  test.printSchema()
  test.show()
  class PreTransformer(override val uid: String) extends Transformer {
    def this() = this(Identifiable.randomUID("familySizeTransformer"))
    override def transform(df: Dataset[_]): DataFrame = {
      val df0 = df.na.drop(Seq("Embarked"))
        .withColumn("FamilySize", col("SibSp") + col("Parch"))
        .drop("SibSp", "Parch", "Ticket", "Cabin")
      val avgAge = df0.agg(avg("Age")).first().getDouble(0)
      //println(avgAge)
      //==> 29.64209269662921
      val avgFare = df0.agg(avg("Fare")).first().getDouble(0)
      df0.na.fill(Map("Age" -> avgAge))
        .na.fill(Map("Fare" -> avgFare))
    }
    override def transformSchema(schema: StructType): StructType = {
      val newSchema = StructType(schema.fields
        .filterNot(field =>
          field.name == "Ticket" ||
          field.name == "SibSp" ||
          field.name == "Parch" ||
          field.name == "Cabin") :+
        StructField("FamilySize", IntegerType, nullable = false))
      newSchema
    }
    override def copy(extra: ParamMap): PreTransformer = {
      defaultCopy(extra)
    }
  }
  val preTransformer = new PreTransformer()
  val train0 = preTransformer.transform(train)
  train0.printSchema()
  train0.show()
  //println(train.filter(col("Age").isNull).count())
  //==> 177
  //println(train0.filter(col("Age").isNull).count())
  //==> 0
  val embarkedIndexer = new StringIndexer().setInputCol("Embarked").setOutputCol("EmbarkedIndex")
  val embarkedEncoder = new OneHotEncoder().setInputCol("EmbarkedIndex").setOutputCol("EmbarkedVec")
  val sexIndexer = new StringIndexer().setInputCol("Sex").setOutputCol("SexIndex")
  val sexEncoder = new OneHotEncoder().setInputCol("SexIndex").setOutputCol("SexVec")
  val assembler = new VectorAssembler()
    .setInputCols(Array("Pclass", "Age", "FamilySize", "Fare", "SexVec", "EmbarkedVec"))
    .setOutputCol("features")
  val lr = new LogisticRegression().setLabelCol("Survived").setFeaturesCol("features")
  val pipeline = new Pipeline().setStages(Array(
    preTransformer,
    sexIndexer, sexEncoder,
    embarkedIndexer, embarkedEncoder,
    assembler,
    lr))
  val model = pipeline.fit(train)
  val predictions = model.transform(test)
  predictions.show()
  //predictions.show(1000)
  val submission = predictions.select("PassengerId", "prediction")
    .withColumn("Survived", col("prediction").cast("int"))
    .drop("prediction")
  //It needs hadoop, so I give up.
//  submission.write.format("csv")
//    .option("header", "true")
//    .save("src/main/resources/submission.csv")
  val subm = submission.toJavaRDD
  val pw = new PrintWriter("src/main/resources/submission.csv")
  pw.println("PassengerId,Survived")
  subm.foreach {
    case Row(p,s) => pw.println(s"$p,$s")
  }
  pw.close()
}
